<html>
  <head>
    <title>Hello OKD</title>
  </head>
  <body bgcolor="#FFF333">
    <h1>
<?php

$name = $_GET['name'];

echo "Hello $name";

?>
    </h1>
  </body>
</html>
